package com.yxq.toolbean;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import com.yxq.valuebean.GoodsSingle;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ShopCar {
	private ArrayList buylist=new ArrayList();
	public void setBuylist(ArrayList buylist) {
		this.buylist = buylist;
	}
	
	public boolean addItem(GoodsSingle single){
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		try {
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/user?serverTimezone=Asia/Shanghai"
					,"root","123456");
			Statement stat =connect.createStatement(); 
			if(single!=null){
				if(buylist.size()==0){	
					GoodsSingle temp=new GoodsSingle();
					temp.setId(single.getId());
					temp.setName(single.getName());
					temp.setPrice(single.getPrice());
					temp.setBuynum(1);
					temp.setNum(single.getNum()-temp.getBuynum());
					
					String sql_1 = "UPDATE fruits set num ='"+(single.getNum()-1)+"'  where id = '"+single.getId()+"'";
					stat.executeUpdate(sql_1);
					
					single.setBuynum(1);
					single.setNum(temp.getNum());
					buylist.add(temp);												
				}
				else{																
					int i=0;				
					for(;i<buylist.size();i++){										
						GoodsSingle temp=(GoodsSingle)buylist.get(i);				
						if(temp.getName().equals(single.getName())){				
							if(single.getBuynum()<single.getNum()) {
								temp.setBuynum(temp.getBuynum()+1);	
								temp.setNum(single.getNum()-1);
					
								String sql_1 = "UPDATE fruits set num ='"+(single.getNum()-1)+"'  where id = '"+single.getId()+"'";
								stat.executeUpdate(sql_1);
								
								single.setBuynum(temp.getBuynum());
								single.setNum(temp.getNum());
								return true;
							}
							else 
								return false;
						}
					}
					if(i>=buylist.size()){		
						GoodsSingle temp=new GoodsSingle();
						temp.setId(single.getId());
						temp.setName(single.getName());
						temp.setPrice(single.getPrice());
						temp.setBuynum(1);
						temp.setNum(single.getNum()-temp.getBuynum());
						
						String sql_1 = "UPDATE fruits set num ='"+(single.getNum()-1)+"'  where id = '"+single.getId()+"'";
						stat.executeUpdate(sql_1);
						
						single.setBuynum(1);
						single.setNum(temp.getNum());
						buylist.add(temp);											//�洢��Ʒ
					}
				}
			}	
			stat.close();  
			connect.close();
        }
		catch(SQLException e) {
			System.out.println(e.toString());
		}
		finally {
		}
		return true;
	}
	/**
	 * @���� �ӹ��ﳵ���Ƴ�ָ�����Ƶ���Ʒ
	 * @���� name��ʾ��Ʒ����
	 */
	public void removeItem(GoodsSingle single){
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		try {
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/user?serverTimezone=Asia/Shanghai"
					,"root","123456");
			Statement stat =connect.createStatement();
			
			if(single.getBuynum()>1){										
				String sql_1 = "UPDATE fruits set num ='"+(single.getNum()+1)+"'  where id = '"+single.getId()+"'";
				stat.executeUpdate(sql_1);
				
				single.setBuynum(single.getBuynum()-1);					
				single.setNum(single.getNum()+1);
			}
			else if(single.getBuynum()==1){		
				String sql_1 = "UPDATE fruits set num ='"+(single.getNum()+1)+"'  where id = '"+single.getId()+"'";
				stat.executeUpdate(sql_1);
				
				single.setNum(single.getNum()+1);	
				
				for(int i=0;i<buylist.size();i++){							//����buylist���ϣ�����ָ�����Ƶ���Ʒ
					GoodsSingle temp=(GoodsSingle)buylist.get(i);   		//��ȡ�����е�ǰλ�õ���Ʒ
					if(temp.getName().equals(single.getName())) {
						buylist.remove(i);
					}
					break;
				}
			}
			stat.close();  
			connect.close();
        }
		catch(SQLException e) {
			System.out.println(e.toString());
		}
		finally {
		}	
	}
	
	public void fresh(GoodsSingle single,GoodsSingle single2) {
		single2.setNum(single.getNum());
		single2.setBuynum(single.getBuynum());
	}
	
	public void reset(ArrayList s) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		try {
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/user?serverTimezone=Asia/Shanghai"
					,"root","123456");
			Statement stat =connect.createStatement();
			String sql = "select * from fruits";  
			ResultSet rs = stat.executeQuery(sql);
			int m=1;
			while(rs.next()) {
				String sql_1 = "UPDATE fruits set num ='50'  where id = '"+m+"'";
				stat.executeUpdate(sql_1);
				m++;
			}
			
			for(int i=0;i<s.size();i++){							
				GoodsSingle temp=(GoodsSingle)s.get(i);   
				temp.setNum(50);
				temp.setBuynum(0);
			}
			stat.close();  
			connect.close();
        }
		catch(SQLException e) {
			System.out.println(e.toString());
		}
	}
	
}