package com.yxq.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yxq.toolbean.MyTools;
import com.yxq.toolbean.ShopCar;
import com.yxq.valuebean.GoodsSingle;

public class BuyServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("action");	//��ȡaction����ֵ
		if(action==null)
			action="";
		if(action.equals("buy"))					//�����ˡ���������
			buy(request,response);						//����buy()����ʵ����Ʒ�Ĺ���
		if(action.equals("remove"))					//�����ˡ��Ƴ�������
			remove(request,response);					//����remove()����ʵ����Ʒ���Ƴ�
		if(action.equals("clear"))					//�����ˡ���չ��ﳵ������
			clear(request,response);					//����clear()����ʵ�ֹ��ﳵ�����
		if(action.equals("delete"))
			delete(request,response);
	}

	//ʵ�ֹ�����Ʒ�ķ���
	protected void buy(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		try {
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/user?serverTimezone=Asia/Shanghai"
					,"root","123456");
			Statement stat =connect.createStatement();
			
			HttpSession session=request.getSession();		
			String strId=request.getParameter("id");		
			int id=MyTools.strToint(strId);
			
			ArrayList goodslist=(ArrayList)session.getAttribute("goodslist");
			GoodsSingle single=(GoodsSingle)goodslist.get(id);
			
			ArrayList buylist=(ArrayList)session.getAttribute("buylist");		//��session��Χ�ڻ�ȡ�洢���û��ѹ�����Ʒ�ļ��϶���
			if(buylist==null)
				buylist=new ArrayList();
			
			ShopCar myCar=new ShopCar();
			myCar.setBuylist(buylist); 						//��buylist����ֵ��ShopCar��ʵ���е�����
			boolean flag=myCar.addItem(single);							//����ShopCar����addItem()����ʵ����Ʒ���Ӳ���
			
			if(flag==false)
			{
				response.setCharacterEncoding("gb2312");
				PrintWriter out = response.getWriter();
				out.print("<script>alert('�����������Ʒ�����ѳ����������������ѡ��������Ʒ��'); window.location='show.jsp' </script>");
				out.flush();
				out.close();
			}
			session.setAttribute("buylist",buylist);
			
			SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String s=df.format(new Date());
			
			String sql_1 = "select id from record";  
			ResultSet rs = stat.executeQuery(sql_1);
			
			int i=0;
			while(rs.next())
				i=rs.getInt("id")+1;
			String name=(String)session.getAttribute("name");
			String sql="insert into record(id,�û�,����,��Ʒ,����,ʱ��,flag) values('"+i+"','"+name+"','����','"+single.getName()+"','1','"+s+"','"+single.getId()+"')";
			stat.executeUpdate(sql);
			response.sendRedirect("show.jsp");				
            
			stat.close();  
			connect.close();
        }
		catch(SQLException e) {
			System.out.println(e.toString());
		}	
	}
	//ʵ���Ƴ���Ʒ�ķ���
	protected void remove(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		try {
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/user?serverTimezone=Asia/Shanghai"
					,"root","123456");
			Statement stat =connect.createStatement();
			
			HttpSession session=request.getSession();
			String strId=request.getParameter("id");		
			int id=MyTools.strToint(strId);
			
			ArrayList buylist=(ArrayList)session.getAttribute("buylist");
			GoodsSingle single=(GoodsSingle)buylist.get(id);
			ArrayList goodslist=(ArrayList)session.getAttribute("goodslist");
			GoodsSingle temp = new GoodsSingle();
			for(int i=0;i<goodslist.size();i++){							
				temp=(GoodsSingle)goodslist.get(i);   		
				if(temp.getName().equals(single.getName())) {
					break;
				}
			}
			
			ShopCar myCar=new ShopCar();
			myCar.setBuylist(buylist);						//��buylist����ֵ��ShopCar��ʵ���е�����
			myCar.removeItem(single);						//����ShopCar����removeItem ()����ʵ����Ʒ�Ƴ�����
			
			myCar.fresh(single, temp);
			session.setAttribute("buylist",buylist);
			
			SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String s=df.format(new Date());
			
			String sql_1 = "select id from record";  
			ResultSet rs = stat.executeQuery(sql_1);
			
			int i=0;
			while(rs.next())
				i=rs.getInt("id")+1;
			
			String name=(String)session.getAttribute("name");
			String sql="insert into record(id,�û�,����,��Ʒ,����,ʱ��,flag) values('"+i+"','"+name+"','�Ƴ�','"+single.getName()+"','1','"+s+"','"+single.getId()+"')";
			stat.executeUpdate(sql);
			response.sendRedirect("shopcar.jsp");
			
			stat.close();  
			connect.close();
        }
		catch(SQLException e) {
			System.out.println(e.toString());
		}
	}
	//ʵ����չ��ﳵ�ķ���
	protected void clear(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		ArrayList buylist=(ArrayList)session.getAttribute("buylist");			//��session��Χ�ڻ�ȡ�洢���û��ѹ�����Ʒ�ļ��϶���
		buylist.clear();														//���buylist���϶���ʵ�ֹ��ﳵ��յĲ���
		
		ArrayList goodslist=(ArrayList)session.getAttribute("goodslist");
		ShopCar myCar=new ShopCar();
		myCar.reset(goodslist);	
		response.sendRedirect("shopcar.jsp");
	}
	
	private void delete(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		try {
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/user?serverTimezone=Asia/Shanghai"
					,"root","123456");
			Statement stat =connect.createStatement();
			
			HttpSession session=request.getSession();		
			String strId=request.getParameter("id");
			int id=MyTools.strToint(strId);
			
			String sql_2 = "DELETE from record where id = '"+id+"'";  	
			stat.executeUpdate(sql_2);
			stat.close();  
			connect.close();
			response.sendRedirect("record.jsp");
        }
		catch(SQLException e) {
			System.out.println(e.toString());
		}
	}
}