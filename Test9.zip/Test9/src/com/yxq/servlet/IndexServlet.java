package com.yxq.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.yxq.valuebean.GoodsSingle;

public class IndexServlet extends HttpServlet {
	private static ArrayList goodslist=new ArrayList();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();		
		session.setAttribute("goodslist",goodslist);
		response.sendRedirect("show.jsp");
	}
	static{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		try {
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/user?serverTimezone=Asia/Shanghai"
					,"root","123456");
			Statement stat =connect.createStatement();
			String sql_1 = "select * from fruits";  
			ResultSet rs = stat.executeQuery(sql_1);
			
            while (rs.next()) {  
            	GoodsSingle single=new GoodsSingle();
    			single.setId(rs.getInt("id"));
    			single.setName(rs.getString("fruit"));
    			single.setPrice(rs.getFloat("price"));
    			single.setBuynum(0);
    			single.setNum(rs.getInt("num"));
    			goodslist.add(single);
            }
			stat.close();  
			connect.close();
        }
		catch(SQLException e) {
			System.out.println(e.toString());
		}
		finally {
		}	
	}
}