package register;

import java.sql.*;
public class LoginDao {
public boolean login(String name,String pwd) throws ClassNotFoundException, SQLException
{
	
	Statement st=null;
	Connection conn=null;
	ResultSet rs=null;
	PreparedStatement ps=null;
	boolean flag=false;
	try {
		 Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/user?useSSL=false&serverTimezone=Asia/Shanghai";
			String user="root";
			String password="123456";
		conn=DriverManager.getConnection(url, user, password);
		
		String sql="select name from users where name= ? and pwd = ?";
		//sql������Ԥ����
		ps=conn.prepareStatement(sql);
		//��sql�����и�ֵ
		ps.setString(1, name);
		ps.setString(2, pwd);
		rs=ps.executeQuery();
		
		if(rs.next())
		{
			flag=true;
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}finally
	 {
		if(rs!=null)
		{
			rs.close();
		}
		if(ps!=null)
		{
			
			ps.close();
		}
		if(conn!=null)
		{
			conn.close();
		}
	 }
	return flag;
}
}