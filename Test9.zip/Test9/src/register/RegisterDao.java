package register;
 
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
 
 
public class RegisterDao {
	ArrayList<String> array=new ArrayList<>();
	public int register(String name,String pwd,String pwd1) throws SQLException
	{
		        ResultSet rs=null;
				Connection conn=null;
				Statement st=null;
				Statement st1=null;
				int count=0;
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					String url="jdbc:mysql://localhost:3306/user?useSSL=false&serverTimezone=Asia/Shanghai";
					String user="root";
					String password="123456";
					conn=DriverManager.getConnection(url, user, password);
					String sql1="select name from users";
					st=conn.createStatement();
					st1=conn.createStatement();
					rs=st1.executeQuery(sql1);
					int num=0;
					while(rs.next())
					{
						String sname=rs.getString("name");
						array.add(sname);
						num++;
					}
					if(name.length()>=1&&name.length()<=10&&pwd.length()>=1&&pwd.equals(pwd1)&&same(name,array))
					{
						String sql="insert into users(id,name,pwd) values('"+num+"','"+name+"','"+pwd+"')";
						count=st.executeUpdate(sql);
					}
					st.close();
					st1.close();
					conn.close();
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
				
				return count;
	}
	public boolean same(String name,ArrayList<String> array)
	{
		
		for(String s:array)
		{
			if(name.equals(s))
			{
				return false;
			}
		}
		return true;
	}
	
}