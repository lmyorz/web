package dao;

import java.sql.*;
import java.util.ArrayList; 

public class JDBC{
	static Connection connection;
	static Statement statement;
	static{
		try{
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		}catch(Exception e){System.out.print(e.toString());}
		try{
		connection = DriverManager.getConnection("jdbc:sqlserver://127.0.0.1:1433;databaseName=st"
				,"sa","123");
		}catch(Exception e){System.out.print(e.toString());}
		try{
		statement=connection.createStatement(1004,1007);
		}catch(Exception e){System.out.print(e.toString());}
	}
	public static ArrayList getName(){
		ArrayList studentList=new ArrayList();
		String sql="SELECT name FROM student";
		try{
		ResultSet rs = statement.executeQuery(sql);
		while(rs.next())
		studentList.add(rs.getString("name"));
		}catch(Exception e){System.out.print(e.toString());}
		return studentList;
	}
	public static void setName(String name){
		String sql="INSERT INTO student VALUES('"+name+"')";
		try{
			statement.executeUpdate(sql);
		}catch(Exception e){System.out.print(e.toString());}
	}
	public static void main(String args[]) {
		getName();
		try {
		statement.close();
		connection.close();
	}catch(Exception e){System.out.print(e.toString());}
	}
}